# AI Pisarz - Dokumentacja dla Claude

## Opis projektu

AI Pisarz to aplikacja Next.js do automatycznego generowania treści SEO. Wykorzystuje Dify (self-hosted) jako silnik workflow'ów AI oraz Supabase jako bazę danych.

## Stack technologiczny

- **Frontend:** Next.js 14, React, TypeScript, Tailwind CSS
- **Backend:** Next.js API Routes
- **Baza danych:** Supabase (self-hosted na Hetzner) + pgvector
- **AI Workflows:** Dify (self-hosted, port 80)
- **Embeddingi:** Jina.ai (`jina-embeddings-v3`, 1024 wymiarów)
- **API zewnętrzne:** SerpData.io (wyszukiwanie SERP), Google Trends

## Konfiguracja (.env.local)

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=http://supabasekong-xxx.sslip.io
NEXT_PUBLIC_SUPABASE_ANON_KEY=xxx
SUPABASE_SERVICE_ROLE_KEY=xxx

# Dify
DIFY_API_BASE_URL=http://localhost/v1
DIFY_KNOWLEDGE_WORKFLOW_KEY=app-xxx
DIFY_HEADERS_WORKFLOW_KEY=app-xxx
DIFY_RAG_WORKFLOW_KEY=app-xxx
DIFY_BRIEF_WORKFLOW_KEY=app-xxx
DIFY_CONTENT_WORKFLOW_KEY=app-xxx

# SerpData
SERPDATA_API_KEY=xxx
SERPDATA_BASE_URL=https://api.serpdata.io/v1
```

---

## Integracja Dify - Workflow'y

### Architektura pipeline'u

```
Projekt (keyword, language)
    ↓
[WF1] Knowledge Building
    ↓ knowledge_graph, information_graph, search_phrases, competitor_headers
[WF2] Headers Generation
    ↓ 3 typy nagłówków (rozbudowane, h2, pytania)
    ↓ (wybór użytkownika)
[WF3] RAG Creation
    ↓ detailed_qa, general_qa
[WF4] Brief Creation
    ↓ brief_json, brief_html
[WF5] Content Generation (iteracyjnie dla każdej sekcji)
    ↓ content_html
FINAL CONTENT
```

### Wywołanie API Dify

```typescript
POST http://localhost/v1/workflows/run
Headers:
  Authorization: Bearer app-xxxxx
  Content-Type: application/json

Body:
{
  "inputs": { /* dane wejściowe */ },
  "response_mode": "blocking",
  "user": "ai-pisarz"
}
```

---

## ⚠️ Ważne uwagi - Workflow'y

1. **Graf informacji (`grafinformacji`) nie generuje się**, jeśli pole `aio` (AI Overview) nie ma ustawionej wartości `"BRAK"`. Gdy `aio` jest puste lub zawiera treść AI Overview, workflow pomija generowanie grafu informacji i zwraca pusty wynik.

---

### Workflow 1: Budowa bazy wiedzy

**Klucz:** `DIFY_KNOWLEDGE_WORKFLOW_KEY`
**Endpoint:** `POST /api/workflows/knowledge`

| Wejście (inputs) | Źródło | Wymagane |
|------------------|--------|----------|
| `keyword` | projekt.keyword | tak |
| `language` | projekt.language | tak |
| `aio` | projekt.ai_overview_content | nie (domyślnie: `"BRAK"`) |

> ⚠️ **UWAGA:** Jeśli `aio` nie jest ustawione na `"BRAK"`, graf informacji nie zostanie wygenerowany!

| Wyjście (outputs) | Tabela docelowa |
|-------------------|-----------------|
| `knowledge_graph` | pisarz_knowledge_graphs.graph_data |
| `grafinformacji` | pisarz_information_graphs.triplets |
| `frazy z serp` | pisarz_search_phrases.phrases |
| `naglowki` | pisarz_competitor_headers.headers |

---

### Workflow 2: Generowanie nagłówków

**Klucz:** `DIFY_HEADERS_WORKFLOW_KEY`
**Endpoint:** `POST /api/workflows/headers`

| Wejście (inputs) | Źródło | Wymagane |
|------------------|--------|----------|
| `keyword` | projekt.keyword | tak |
| `language` | projekt.language | tak |
| `frazy` | pisarz_search_phrases.phrases | tak |
| `graf` | JSON.stringify(knowledge_graph) | tak |
| `headings` | pisarz_competitor_headers.headers | nie |

| Wyjście (outputs) | Tabela docelowa |
|-------------------|-----------------|
| `naglowki_rozbudowane` | pisarz_generated_headers (type: rozbudowane) |
| `naglowki_h2` | pisarz_generated_headers (type: h2) |
| `naglowki_pytania` | pisarz_generated_headers (type: pytania) |

---

### Workflow 3: RAG Creation

**Klucz:** `DIFY_RAG_WORKFLOW_KEY`
**Endpoint:** `POST /api/workflows/rag`

| Wejście (inputs) | Źródło | Wymagane |
|------------------|--------|----------|
| `keyword` | projekt.keyword | tak |
| `language` | projekt.language | tak |
| `headings` | wybrane nagłówki (is_selected=true) | tak |

| Wyjście (outputs) | Tabela docelowa |
|-------------------|-----------------|
| `dokladne` | pisarz_rag_data.detailed_qa |
| `ogolne` | pisarz_rag_data.general_qa |

---

### Workflow 4: Brief Creation

**Klucz:** `DIFY_BRIEF_WORKFLOW_KEY`
**Endpoint:** `POST /api/workflows/brief`

| Wejście (inputs) | Źródło | Wymagane |
|------------------|--------|----------|
| `keyword` | projekt.keyword | tak |
| `keywords` | pisarz_search_phrases.phrases | tak |
| `headings` | wybrane nagłówki | tak |
| `knowledge_graph` | JSON.stringify(graph_data) | tak |
| `information_graph` | JSON.stringify(triplets) | tak |

| Wyjście (outputs) | Tabela docelowa |
|-------------------|-----------------|
| `brief` | JSON array BriefItem[] |
| `html` | pisarz_briefs.brief_html |

**Struktura BriefItem:**
```typescript
interface BriefItem {
  heading: string;
  knowledge: string;
  keywords: string;
}
```

---

### Workflow 5: Content Generation (iteracyjny)

**Klucz:** `DIFY_CONTENT_WORKFLOW_KEY`
**Endpoint:** `POST /api/workflows/content`

Wywoływany **dla każdej sekcji osobno** z systemem anty-powtórzeniowym.

| Wejście (inputs) | Źródło | Wymagane |
|------------------|--------|----------|
| `naglowek` | aktualny nagłówek HTML | tak |
| `language` | projekt.language | tak |
| `knowledge` | briefItem.knowledge | tak |
| `keywords` | briefItem.keywords | tak |
| `headings` | wszystkie nagłówki (kontekst struktury) | tak |
| `done` | **streszczenia poprzednich sekcji** (2-3 zdania każda) | tak |
| `keyword` | projekt.keyword | tak |
| `last_section` | pełna treść ostatniej sekcji (dla ciągłości) | nie |
| `upcoming` | plan przyszłych sekcji z brief (temat każdej) | nie |
| `instruction` | **instrukcja anty-powtórzeniowa** (auto-generowana) | nie |

| Wyjście (outputs) | Tabela docelowa |
|-------------------|-----------------|
| `result` | pisarz_content_sections.content_html |

**Context Store:** `pisarz_context_store` przechowuje:
- `accumulated_content` - pełna treść (backup)
- `current_heading_index` - indeks aktualnej sekcji
- `section_summaries` - JSON array streszczeń `[{heading, summary, topics}]`
- `last_section_content` - pełna treść ostatniej sekcji

**System anty-powtórzeniowy:**

Model przy każdej sekcji otrzymuje:
1. **Streszczenia poprzednich sekcji** (zamiast pełnej treści) - oszczędność tokenów
2. **Pełną ostatnią sekcję** - dla zachowania ciągłości stylu
3. **Plan przyszłych sekcji** - wie co będzie pisane później
4. **Instrukcję anty-powtórzeniową** - lista tematów do unikania

```
Przykład instrukcji:
WAŻNE ZASADY:
1. NIE powtarzaj informacji z poprzednich sekcji.
2. NIE pisz o tematach zaplanowanych na kolejne sekcje.
3. Skup się TYLKO na aktualnym nagłówku.

Tematy już omówione (NIE powtarzaj): Wprowadzenie, Historia
Tematy na kolejne sekcje (NIE pisz o nich teraz): Przyszłość, Podsumowanie
```

**Pliki implementacji:**
- `src/lib/summarizer.ts` - funkcje streszczania i budowania kontekstu
- `src/app/api/workflows/content/route.ts` - API endpoint
- `src/lib/orchestrator/index.ts` - logika orkiestracji

---

## Struktura bazy danych

```
pisarz_projects
├── id, keyword, language, ai_overview_content
├── current_stage, status

pisarz_workflow_runs
├── id, project_id, stage, stage_name, status, error_message

pisarz_knowledge_graphs
├── id, project_id, graph_data (JSON)

pisarz_information_graphs
├── id, project_id, triplets (JSON)

pisarz_search_phrases
├── id, project_id, phrases (text)

pisarz_competitor_headers
├── id, project_id, headers (text)

pisarz_generated_headers
├── id, project_id, header_type, headers_html, is_selected

pisarz_rag_data
├── id, project_id, detailed_qa, general_qa

pisarz_briefs
├── id, project_id, brief_json, brief_html

pisarz_content_sections
├── id, project_id, section_order, heading_html
├── heading_knowledge, heading_keywords
├── content_html, status

pisarz_context_store
├── project_id, accumulated_content, current_heading_index
├── section_summaries (JSONB), last_section_content

pisarz_content_sections
├── ... + summary (TEXT) - streszczenie sekcji

pisarz_generated_content
├── id, project_id, content_html, content_text
```

---

## RSS & Google Trends - Dane z gazetek

Nowa funkcjonalność agregująca trendy z Google Trends oraz dane z gazetek (RSS). Dane są wzbogacane o embeddingi wektorowe do wyszukiwania semantycznego.

### Tabela: `rrs_google_trends`

| Kolumna | Typ | Opis |
|---------|-----|------|
| `id` | integer | Klucz główny |
| `trend_id` | text | Unikalny ID trendu (format: `YYYYMMDD-keyword`) |
| `keyword` | text | Słowo kluczowe trendu |
| `approx_traffic` | integer | Przybliżony ruch (w tysiącach) |
| `pub_date` | timestamptz | Data publikacji trendu |
| `description` | text | Opis trendu |
| `media` | text | Lista źródeł medialnych |
| `media_links` | text | Linki do artykułów (markdown format) |
| `picture` | text | URL obrazka trendu |
| `picture_source` | text | Źródło obrazka |
| `has_interia` | boolean | Czy Interia ma artykuł o tym trendzie |
| `embedding` | vector(1024) | **Embedding wektorowy** (pgvector) |
| `embedding_text` | text | Tekst użyty do generowania embeddingu |
| `fetched_at` | timestamptz | Data pobrania danych |
| `created_at` | timestamptz | Data utworzenia rekordu |

### Model embeddingowy

- **Provider:** [Jina.ai](https://jina.ai/)
- **Model:** `jina-embeddings-v3`
- **Wymiary wektora:** 1024
- **Zastosowanie:** Wyszukiwanie semantyczne, podobieństwo trendów, rekomendacje

### Przykład zapytania z embeddingami (pgvector)

```sql
-- Wyszukiwanie podobnych trendów
SELECT keyword, approx_traffic,
       embedding <=> '[0.1, 0.2, ...]'::vector AS distance
FROM rrs_google_trends
ORDER BY distance
LIMIT 10;
```

### Integracja

Dane są pobierane automatycznie z:
- Google Trends (polskie trendy)
- RSS feeds z gazetek/portali informacyjnych
- Artykuły z Interia.pl (jeśli dostępne)

---

## Kluczowe pliki

| Plik | Opis |
|------|------|
| `src/lib/dify/client.ts` | Klient Dify API |
| `src/lib/orchestrator/index.ts` | Orkiestrator workflow'ów |
| `src/app/api/workflows/*/route.ts` | API routes dla workflow'ów |
| `src/app/(dashboard)/projects/[id]/page.tsx` | Strona projektu |
| `src/app/(dashboard)/settings/workflows/page.tsx` | Konfiguracja workflow'ów |

---

## Uruchomienie Dify

```bash
cd ~/dify/docker
docker compose up -d
```

Dify działa na porcie 80: http://localhost

---

## Statusy projektu

1. `draft` - nowy projekt
2. `knowledge_building` → `knowledge_built`
3. `headers_generating` → `headers_generated` → `headers_selected`
4. `rag_creating` → `rag_created`
5. `brief_creating` → `brief_created`
6. `content_generating` → `completed`
7. `error` - błąd w dowolnym etapie

---

## 🐛 Znane błędy do naprawienia

### 1. Brief HTML nie renderuje się poprawnie

**Problem:** Brief workflow zwraca HTML opakowany w markdown code blocks (` ```html `) oraz tagi `<html><body>`. Mimo że funkcja `formatBriefHtml` usuwa te tagi, HTML wyświetla się jako tekst zamiast być renderowany.

**Lokalizacja:**
- `src/app/(dashboard)/projects/[id]/page.tsx` - karta "Brief contentu"
- `src/components/workflow/stage-editor.tsx` - sekcja Stage 4

**Obecne rozwiązanie:** Dodano funkcję `formatBriefHtml()` która usuwa markdown code blocks i tagi html/body, ale to nie rozwiązuje problemu.

**Do zbadania:**
- Sprawdzić console.log w przeglądarce (dodane debugowanie)
- Możliwe że dane są escapowane w bazie danych
- Sprawdzić czy Tailwind prose class działa poprawnie
- Rozważyć użycie dedykowanego komponentu do renderowania HTML

**Status:** Do naprawienia

---

### 2. RAG Workflow - przekroczenie limitu tokenów

**Problem:** Dify RAG workflow przekracza limit 200k tokenów (żąda ~570k tokenów). Aplikacja wysyła tylko 222 znaki headings, więc problem jest wewnątrz workflow Dify.

**Błąd:**
```
PluginInvokeError: This endpoint's maximum context length is 200000 tokens.
However, you requested about 569607 tokens
```

**Przyczyna:** Workflow RAG w Dify prawdopodobnie:
- Ładuje cały knowledge_graph który jest bardzo duży
- Ma źle skonfigurowane node'y które łączą za dużo danych
- Używa modelu z małym kontekstem

**Do naprawienia w Dify:**
1. Sprawdzić workflow RAG - które node'y generują dużo tokenów
2. Zmniejszyć rozmiar knowledge_graph przed wysłaniem do modelu
3. Użyć modelu z większym kontekstem (np. Claude 3.5 z 200k)
4. Włączyć "middle-out" kompresję jeśli dostępna

**Status:** Do naprawienia w Dify

---

## 🔄 Punkty przywracania (Restore Points)

### Restore Point 1 - 2026-01-21
**Commit:** `9e03a32`
**Opis:** Aplikacja działa, dodane debug logging do Brief workflow, anti-repetition system wyłączony (nie wdrożony w Dify)

**Aby przywrócić ten stan:**
```bash
git reset --hard 9e03a32
```
